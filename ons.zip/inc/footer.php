 <!-- :: Footer -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                   
                    <!--<div class="col-sm-6 col-md-6 col-lg-2">
                        <div class="footer-title">
                            <h4>About Us Links</h4>
                        </div>
                        <ul class="links">
                            <li><a href="#">Leadership Team</a></li>
                            <li><a href="#">Board Of Directors</a></li>
                            <li><a href="#">ONS Journey</a></li>
							</ul>
                    </div>-->
					
					<div class="col-sm-6 col-md-6 col-lg-3">
                        <div class="footer-title">
                            <h4>Quick Links</h4>
                        </div>
                        <ul class="links">
                            <li><a href="index.php">Home</a></li>
							<li><a href="leadership-team.php">Leadership Team</a></li>
                            <li><a href="leadership-team.php#directors">Board Of Directors</a></li>
                            <li><a href="about.php">About us</a></li>
                            <li><a href="manufacturing-infrastructure.php">Manufacturing Infrastructure overview</a></li>
                            <li><a href="career.php">Career</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </div>
					
					
                    <div class="col-sm-6 col-md-6 col-lg-3">
                        <div class="footer-title">
                            <h4>Company Policy</h4>
                        </div>
                        <ul class="links">
                            <li><a href="quality-policy.php">Quality policy</a></li>
                            <li><a href="environment-health-safety.php">Environment, Health & Safety</a></li>
                            <li><a href="sustainability.php">Sustainability</a></li>
                            <li><a href="values.php">Values</a></li>
                            <li><a href="economic-responsibility.php#economic">Economic Responsibility</a></li>
                            <li><a href="economic-responsibility.php#social">Social Responsibilities</a></li>
							</ul>
                    </div>
                    
					
					<div class="col-sm-6 col-md-6 col-lg-3">
                        <div class="footer-title">
                            <h4>Products Links</h4>
                        </div>
                        <ul class="links">
                            <li><a href="#">Specialty Ingredients</a></li>
<li><a href="specialty-chemical.php#special">Fine Chemicals</a></li>
<li><a href="specialty-chemical.php#fine">Human Nutrition and health ingredients</a></li>
<li><a href="nutrition-health.php">Nutrition & Health</a></li>
<li><a href="personal-consumer-care.php#hair">Hair care and hair growth ingredients</a></li>
<li><a href="personal-consumer-care.php#skin">Skin care ingredients</a></li>
<li><a href="personal-consumer-care.php#antibacterial">Antibacterial ingredients</a></li>
<!--<li><a href="#">Emollients</a></li>
<li><a href="#">Paints and Coatings</a></li>
<li><a href="#">Preservative ingredients</a></li>-->
							</ul>
                    </div>
					
				<!--	<div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="logo">
                            <img class="img-fluid" src="assets/images/logo/01_logo.png" alt="Footer Logo">
                            <p>Gazolin Are A Industry &amp; Manufacturing Services Provider Institutions. Suitable For Factory, Manufacturing, Industry, Engineering, Construction And Any Related Industry Care Field.</p>
                        </div>
                    </div>-->
					
					
					
					
					
					
                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="footer-title">
                            <h4>Contact Information</h4>
                        </div>
						
						<div class="add_res">
						<p>Manufacturing Unit<br> Khatta No. 538, Khasra No. 586 Kandela Industrial Area, Kandela Teh - Kairana - Distt - Shamli <br>Uttar Pradesh - 247776</p>
						<p>Corrospondence And Corporate Office Address <br>, A24/12 Awas vikas sector 5 sapna Ist Tronica city, Tronica Industrial Area, Loni, Ghaziabad. Pin Code-201102</p>
						<p>Tel: +91 9810891258</p>
						<p>Mob: info@onsindustries.com</p>
						</div>
						
						
                        <ul class="icon">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="copyright">
                <div class="container">
                    <p>@Copyright 2022. All Right Reseved &nbsp; &nbsp;|| Designed by <a href="https://www.cssfounder.com"><strong>Css Founder.com</strong></a></p>
                </div>
            </div>
        </footer>
        
        <!-- :: Scroll UP -->
        <div class="scroll-up">
            <a class="move-section" href="#page">
                <i class="fas fa-long-arrow-alt-up"></i>
            </a>
        </div>