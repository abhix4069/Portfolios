<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries">
        <meta name="keywords" content="ONS Industries">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>Leadership Team | ONS Industries</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>

    <body>

 <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
	<?php include('inc/header.php');?>  
        

 
        <!-- :: Breadcrumb Header -->
        <section class="breadcrumb-header style-2" id="page" style="background-image: url(img/banner/banner-chemical-industry.jpg)">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner">
                            <h1>Leadership Team</h1>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fas fa-angle-right"></i></li>
                                <li>Leadership Team</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		



 <!-- :: Team -->
       
		
		<!-- :: Provide -->
		
		<!-- :: FAQs -->
		<div class="faqs-page pt-5 teams">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 ">
					<div class="text-center">
					<h3>Key Persons: Team Leaders</h3>
					</div>
					</div>
					<div class="col-lg-12">
						<div class="faq style-2">
							<div class="faq-box">
								<button class="btn btn-primary click" type="button" data-bs-toggle="collapse" data-bs-target="#faqs-1" aria-expanded="false" aria-controls="faqs-1">Dr. P.K. Verma<i class="fas fa-angle-right"></i>
								</button>
								<div class="collapse " id="faqs-1">
								
									<div class="card card-body about-text text-justify">
									<div class="row">
									<div class="col-md-8">
										PHD from HBTI Kanpur, Ex R&D head Jubilant Ingrevia having more than 35 years of experience in R&D, project management and new product development in API, Agro and fine chemical industries. Dr. Verma is first to develop and commercialize continuous vapour phase ammoxidation catalyst in the country to manufacture cyanopyridine from picolines. Dr. Verma developed and commercialize many fixed and fluidized bed catalytic processes for manufacturing fine chemicals, drug intermediates and agro intermediates.
										<br>
										He received national awards in 1996, 2004 and 2006 for these achievements. Received Acharya PC ray and many more awards for contributions to chemical industry.
									</div>
									 <div class="col-md-4">
									 <img class="img-fluid" src="img/team/pk-verma.jpg" alt="01 team">
									 </div>
									</div>
									</div>
									
								</div>
							</div>
							<div class="faq-box">
								<button class="btn btn-primary click" type="button" data-bs-toggle="collapse" data-bs-target="#faqs-2" aria-expanded="false" aria-controls="faqs-2">Saurabh Singh<i class="fas fa-angle-right"></i>
								</button>
								<div class="collapse" id="faqs-2">
									<div class="card card-body about-text">
									
									<div class="row">
									<div class="col-md-8">
										35 years, is B.E. (Hons) in Chemical and has been associated with various chemical industries in India. He has over 15 years of experience in manufacturing and operational excellence and will lead the overall operations for ONS industries. He has been instrumental in bringing new technologies, developing and managing projects for the Companies.
									</div>
									<div class="col-md-4">
									<img class="img-fluid" src="img/team/saurabh.jpg" alt="02 team">
									</div>
									</div>
									</div>
									
								</div>
							</div>
							
						</div>
					</div>
					<div class="col-lg-12">
						<div class="faq style-2">
							<div class="faq-box">
								<button class="btn btn-primary click" type="button" data-bs-toggle="collapse" data-bs-target="#faqs-4" aria-expanded="false" aria-controls="faqs-4">Harendra Singh<i class="fas fa-angle-right"></i>
								</button>
								<div class="collapse" id="faqs-4">
									<div class="card card-body about-text">
									
									<div class="row">
									<div class="col-md-8">
										40 years, is MBA in supply chain and marketing. He has over 20 years of experience in supply chain and marketing in various industries in India and will look after the supply chain and marketing for ONS industries. He has been instrumental in developing new market potentials for the companies.
									</div>
									<div class="col-md-4">
									<img class="img-fluid" src="img/team/harender.jpg" alt="04 team">
									</div>
									</div>
									</div>
								</div>
							</div>
							<div class="faq-box">
								<button class="btn btn-primary click" type="button" data-bs-toggle="collapse" data-bs-target="#faqs-5" aria-expanded="false" aria-controls="faqs-5">Shashank Khare<i class="fas fa-angle-right"></i>
								</button>
								<div class="collapse show" id="faqs-5">
									<div class="card card-body about-text">
									<div class="row">
									<div class="col-md-8">
										38 years, is MSc. in chemistry. He has over 17 years of experience in quality control and quality assurance in various Pharma Companies and will lead the quality and regulatory department for ONS industries. He has rich experience in conducting USFDA and other regulatory audits.
									</div>
									<div class="col-md-4">
									<img class="img-fluid" src="img/team/shanku.jpg" alt="04 team">
									</div>
									</div>
									</div>
								</div>
							</div>
							
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
    <!--:: Provide 3 -->
	
	
	 <section class="team home-2 py-100-70" id="directors">
            <div class="container">
                <div class="sec-title home-2">
                    <div class="row justify-content-center">
                        <div class="col-lg-12">
                        <div class="text-center">
                            <h3>Board of Directors</h3>
                        </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    
                    <div class="col-md-6 col-lg-3">
                        <div class="team-box">
                            <div class="img-box">
                                <img class="img-fluid" src="img/team/saurabh.jpg" alt="02 team">
                                </div>
                            <div class="text-box text-center">
                                <h5><a href="#">Saurabh Singh</a></h5>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="team-box">
                            <div class="img-box">
                                <img class="img-fluid" src="img/team/harender.jpg" alt="03 team">
                                </div>
                            <div class="text-box text-center">
                                <h5><a href="#">Harendra Singh</a></h5>
                               
                            </div>
                        </div>
                    </div>
					
					 <div class="col-md-6 col-lg-3">
                        <div class="team-box">
                            <div class="img-box">
                                <img class="img-fluid" src="img/team/shanku.jpg" alt="04 team">
                                </div>
                            <div class="text-box text-center">
                                <h5><a href="#">Shashank Khare</a></h5> 
                               
                            </div>
                        </div>
                    </div>
					
                </div>
            </div>
        </section>
	
	<!--<section class="p-5 teams2">
		<div class="teams">
		<div class="container">
		<div class="row">
		
		
		<div class="col-lg-12 " >
		<div class="text-center">
			<h3>Board of Directors</h3>
		</div>
		</div>
		
		<div class="col-md-12">
		<div class="leaderName">
		<div class="row justify-content-center">
		
		
		<!--------------------
		<div class="col-lg-3">
		<div class="leads">
		<h4>Saurabh Singh</h4>
		</div>
		</div>
		<!--------------------
		
		<!--------------------
		<div class="col-lg-3">
		<div class="leads">
		<h4>Harendra Singh</h4>
		</div>
		</div>
		<!-------------------->
		
		
		
		
		<!--------------------
		<div class="col-lg-3">
		<div class="leads">
		<h4>Shashank Khare</h4>
		</div>
		</div>
		<!--------------------
		
		</div>
		</div>
		</div>
		
		
		</div>
		</div>
		</div>
		</section>->







  
  	<?php include('inc/footer.php');?> 
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
    </body>


</html>