<!doctype html>
<html lang="en">
    

<head>
        <!-- :: Required Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="ONS Industries">
        <meta name="keywords" content="ONS Industries">

        <!-- :: Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- :: Favicon -->
        <link rel="icon" type="image/png" href="assets/images/favicon.png">

        <!-- :: Title -->
        <title>Manufacturing Infrastructure | ONS Industries</title>

        <!-- :: Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&amp;family=Heebo:wght@400;500;600;700&amp;display=swap">

        <!-- :: Fontawesome -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <!-- :: Flaticon -->
        <link rel="stylesheet" href="assets/fonts/flaticon/style.css">

        <!-- :: Animate -->
        <link rel="stylesheet" href="assets/css/animate.css">
        
        <!-- :: Owl Carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        
        <!-- :: Lity -->
        <link rel="stylesheet" href="assets/css/lity.min.css">
        
        <!-- :: Nice Select CSS -->
        <link rel="stylesheet" href="assets/css/nice-select.css">
        
        <!-- :: Magnific Popup CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">

        <!-- :: Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- :: Style Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
            <![endif]-->
    </head>

    <body>

 <!------------
        <div class="loading">
            <div class="loading-box">
                <div class="lds-roller">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
		-------------->
        
	<?php include('inc/header.php');?>  
        

 
        <!-- :: Breadcrumb Header -->
        <section class="breadcrumb-header style-2" id="page" style="background-image: url(img/banner/banner-chemical-industry.jpg)">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner">
                            <h1>Manufacturing Infrastructure</h1>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fas fa-angle-right"></i></li>
                                <li>Manufacturing Infrastructure</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		



 <!-- :: Team -->
       
		<section class="about-us home-3 py-100">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-6">
                        <div class="about-us-img-box">
                            <div class="img-box" style="background-image: url(img/mfg.jpeg)"></div> 
                        </div>
                    </div>
                    <div class="col-lg-6 pt-5">
                        <div class="about-us-text-box">
                            <div class="sec-title home-3">
                                <p class="sec-explain ">ONS currently has one operational site located at Kandela Industrial Area, Shamli in Uttar Pradesh.</p>
                                <p class="sec-explain ">The manufacturing site is well maintained with a large variety of reactor sizes, MOC and downstream processing including pressure filters, dryers etc. The site has adequate utilities for heating, chilling and cooling.</p>
                                <p class="sec-explain ">Our manufacturing site has additional land available for future expansion. With this we remain confident of continuing on our sustainable growth trajectory in the coming years.</p>
                       
								</div>
                    </div>
                </div>
				
		
				
            </div>
        </section>
		
		
		<div class="container">
		<div class="manufacturing_capcity">
		<h3 id ="manufacturing-capaciy">MANUFACTURING CAPACITY</h3>
		<!--<p><strong>ONS operates  One manufacturing facilities. These are located at:</strong></p>
		<p>1. Kandela, Shamli</p>-->
		</div>
		</div>
		
		
		<section class="manu-details">
		<div class="container">
		<h6>The unit spread across a land area of approximately 700 Sq meter. The area, manufacturing capacity details are:</h6>
		<div class="row justify-content-center">
		
		<div class="col-lg-10">
		
		<div class="chemical-list">
		<table class="chem-table">
		<!---------------->
		<thead>
		<tr>
		<th>S.N</th>
		<th>Product</th>
		<th>Production capacity (Mt/Month)</th>
		
		</tr>
		</thead>
		<!---------------->
		<!---------------->
		<tbody>
		
		<tr>
		<td>1.</td>
		<td>2Hydroxy 5Methyl Pyridine</td>
		<td>3.0</td>
		</tr>
		
		<tr>
		<td>2.</td>
		<td>Phenyl Hydrazine HCl</td>
		<td>5.0</td>
		</tr>
		
		<tr>
		<td>3.</td>
		<td>4-Amino Pyridine</td>
		<td>5.0</td>
		</tr>
		
		<tr>
		<td>4.</td>
		<td>Zinc Picolinate</td>
		<td>5.0</td>
		</tr>
		
		<tr>
		<td>5.</td>
		<td>Zinc Pyrithione (100%)</td>
		<td>10.0</td>
		</tr>
		
		<tr>
		<td>6.</td>
		<td>Copper Pyrithione</td>
		<td>5.0</td>
		</tr>
		
		<tr>
		<td>7.</td>
		<td>Sodium Pyrithione (40%)</td>
		<td>10.0</td>
		</tr>
		
		<tr>
		<td>8.</td>
		<td>Niacinamide</td>
		<td>10.0</td>
		</tr>
		
		<tr>
		<td>9.</td>
		<td>Minoxidil</td>
		<td>5.0</td>
		</tr>
		
		
		
		<tr>
		<td>10.</td>
		<td>Potassium/Ammonium Thioglycolate</td>
		<td>30.0</td>
		</tr>
		
		<tr>
		<td>11.</td>
		<td>Calcium Thioglycolate</td>
		<td>10.0</td>
		</tr>
		
		<tr>
		<td>12.</td>
		<td>Chromium Picolinate</td>
		<td>5.0</td>
		</tr>
		
		
		
		<tr>
		<td>13.</td>
		<td>Chromium Nicotinate</td>
		<td>5.0</td>
		</tr>
		
		
		
		<tr>
		<td>14.</td>
		<td>Zinc PolyNicotinate</td>
		<td>5.0</td>
		</tr>
		
		
		
		


		
		
		
		</tbody>
		<!---------------->
		</table>
		</div>
		
		</div>
		
		<h5 id="utilities">Utilities</h5>
		<!----------Utility--------------->
		<div class="col-lg-10">
		
		<div class="chemical-list">
		<table class="chem-table">
		<!---------------->
		<thead>
		<tr>
		<th>S.N.</th>
		<th>Description</th>
		<th>Capacity</th>
		
		</tr>
		</thead>
		<!---------------->
		<!---------------->
		<tbody>
		
		<tr>
		<td>1.</td>
		<td>Colling Tower</td>
		<td>200TR</td>
		</tr>
		
		<tr>
		<td>2.</td>
		<td>Chilled Plant</td>
		<td>30TR</td>
		</tr>
		
		
		<tr>
		<td>3.</td>
		<td>Boiler</td>
		<td>600kg/hr</td>
		</tr>
		
		<tr>
		<td>4.</td>
		<td>Nitrogen Plant</td>
		<td>100 nm3/Hr.</td>
		</tr>
		
		</tbody>
		<!---------------->
		</table>
		</div>
		
		</div>
		
		<!----------Utility--------------->
		<!----------Equipment--------------->
	
		<!----------Equipment--------------->
		<!----------f--------------->
		<h5 id="equipment">Description of Equipment &amp; Capacity</h5>
		
		<div class="col-lg-10">
		
		<div class="chemical-list">
		<table class="chem-table">
		<!---------------->
		<thead>
		<tr>
		<th>Sr. No</th>
		<th>Equipment</th>
		<th>No.</th>
		<th>Capacity</th>
		
		</tr>
		</thead>
		<!---------------->
		<!---------------->
		<tbody>
		
		<tr>
		<td>1.</td>
		<td>Glass Lined Reactor with glass overhead system</td>
		<td>02</td>
		<td>5 KL and 6 KL</td>
		</tr>
		
		<tr>
		<td>2.</td>
		<td>SS Reactor</td>
		<td>01</td>
		<td>5 KL</td>
		</tr>
		
		<tr>
		<td>3.</td>
		<td>SS Centrifuge</td>
		<td>01</td>
		<td>48”</td>
		</tr>
		
		<tr>
		<td>4.</td>
		<td>SS Sparkler Filter</td>
		<td>01</td>
		<td>18’’24 Plates</td>
		</tr>
		
		<tr>
		<td>5.</td>
		<td>SS RCV Dryer</td>
		<td>01</td>
		<td>1 KL</td>
		</tr>
		
		<tr>
		<td>6.</td>
		<td>SS Miller</td>
		<td>01</td>
		<td>150 Hg/Hr.</td>
		</tr>
		
		<tr>
		<td>7.</td>
		<td>SS Vibro Shifter</td>
		<td>01</td>
		<td>200 Kg/Hr</td>
		</tr>
		
		<tr>
		<td>8.</td>
		<td>Vacuum Pump</td>
		<td>01</td>
		<td>700 mmHg</td>
		</tr>
		
		<tr>
		<td>9.</td>
		<td>Scrubber System</td>
		<td>01</td>
		<td>2000 CFM</td>
		</tr>
		
		<tr>
		<td>10.</td>
		<td>SS Tank</td>
		<td>02</td>
		<td>10 KL</td>
		</tr>
		
		
		</tbody>
		<!---------------->
		</table>
		</div>
		
		</div>
		
		<!----------f--------------->
		
		</div>
		</div>
		</section>
		
  
  	<?php include('inc/footer.php');?> 
        
        <!-- :: JavaScript Files -->
        <!-- :: jQuery JS -->
        <script src="assets/js/jquery-3.6.0.min.js"></script>

        <!-- :: Bootstrap JS Bundle With Popper JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        
        <!-- :: Owl Carousel JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        
        <!-- :: Lity -->
        <script src="assets/js/lity.min.js"></script>
        
        <!-- :: Nice Select -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        
        <!-- :: Waypoints -->
        <script src="assets/js/jquery.waypoints.min.js"></script>

        <!-- :: CounterUp -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        
        <!-- :: Magnific Popup -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		
		<!-- :: MixitUp -->
        <script src="assets/js/mixitup.min.js"></script>
        
        <!-- :: Main JS -->
        <script src="assets/js/main.js"></script>
    </body>


</html>